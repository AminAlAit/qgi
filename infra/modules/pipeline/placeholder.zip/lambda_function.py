"""Placeholder for a TF-managed Lambda whose real code has not been
deployed by CI/CD yet. See qgi-infra/modules/pipeline/main.tf for
the rationale (#153). Fix: trigger deploy-lambdas.yml in qgi-pipeline.
"""
import os

def lambda_handler(event, context):
    fn = os.environ.get("AWS_LAMBDA_FUNCTION_NAME", "<unknown>")
    raise RuntimeError(
        f"PLACEHOLDER STUB STILL LIVE for Lambda '{fn}'. "
        f"Terraform created or recreated this function but CI/CD "
        f"(qgi-pipeline deploy-lambdas.yml) has not yet deployed "
        f"the real code. Trigger a deploy with: "
        f"`gh workflow run deploy-lambdas.yml --repo AminAlAit/qgi-pipeline "
        f"-f deploy_all=true` or push any commit touching "
        f"lambdas/{fn.removeprefix('qgi-')}/. See #153."
    )
