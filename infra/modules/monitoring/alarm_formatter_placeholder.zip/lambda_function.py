"""Placeholder for qgi-sns-alarm-formatter. See #412.
Real code in qgi-pipeline/lambdas/qgi-sns-alarm-formatter/ deploys
via qgi-pipeline deploy-lambdas.yml workflow.
"""
def lambda_handler(event, context):
    raise RuntimeError(
        "PLACEHOLDER STUB STILL LIVE for qgi-sns-alarm-formatter. "
        "Terraform created this function but CI/CD has not deployed "
        "the real code. Trigger: `gh workflow run deploy-lambdas.yml "
        "--repo AminAlAit/qgi-pipeline -f deploy_all=true` or push a "
        "commit touching lambdas/qgi-sns-alarm-formatter/."
    )
